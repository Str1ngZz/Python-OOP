from re import X
import tkinter as tk
from tkinter import *
from tkinter.font import BOLD
from turtle import back
from xml.dom.pulldom import END_DOCUMENT
from PIL import ImageTk, Image


def pay(window):

    credit_lbl = tk.Label(window, text = 'Enter a credit:')
    credit_lbl.place(x=950, y=125)

    ent_credit = tk.Entry(window)
    ent_credit.place(x=950, y=150)

#     enter_btn = tk.Button(window, text='enter', bg="#604CDE",
# fg='white', command=pay2)
#     enter_btn.place(x = 950, y = 200)
#     enter_btn.config(height = 1, width = 15)


# def pay2():
#    if latte >= ent_credit:
    # text = tk.Label(window, text = 'afdsj')
    # text.place(x = 950, y = 500)
#        quit()

def latte():
    # command=pay()

    window2 = tk.Tk()
    window2.geometry('1920x1080')
    window2.title('Coffee machine')
    latte = float(2)
    lbl1= tk.Label(window2, text = 'Your chosen drink is: LATTE')
    lbl1.configure(font=("Bernard MT", 13, 'bold'))
    lbl1.place(x = 950, y = 50)

    cost = tk.Label(window2, text = f'Cost: {latte} credit')
    cost.place(x = 950, y = 70)

    clear_btn = tk.Button(window2, text='GO BACK', bg="red", fg='white', command=window2.destroy)
    clear_btn.place(x = 950, y = 500)

def espresso():
    # command=pay()
    window2 = tk.Tk()
    window2.geometry('1920x1080')
    window2.title('Coffee machine')
    lbl1= tk.Label(window2, text = 'Your chosen drink is: ESPRESSO')
    lbl1.configure(font=("Bernard MT", 13, 'bold'))
    lbl1.place(x = 950, y = 50)

    cost = tk.Label(window2, text = 'Cost: 0,50 credit')
    cost.place(x = 950, y = 70)

    clear_btn = tk.Button(window2, text='GO BACK', bg="red", fg='white', command=window2.destroy)
    clear_btn.place(x = 950, y = 500)

def mochaccino():
    # command=pay()
    window2 = tk.Tk()
    window2.geometry('1920x1080')
    window2.title('Coffee machine')

    lbl1= tk.Label(window2, text = 'Your chosen drink is: MOCHACCINO)')
    lbl1.configure(font=("Bernard MT", 13, 'bold'))
    lbl1.place(x = 950, y = 50)

    cost = tk.Label(window2, text = 'Cost: 1,50 credit')
    cost.place(x = 950, y = 70)
    cost = 20

    clear_btn = tk.Button(window2, text='GO BACK', bg="red", fg='white', command=window2.destroy)
    clear_btn.place(x = 950, y = 500)

def cappuccino():
    # command=pay()
    

    window2 = tk.Tk()
    window2.geometry('1920x1080')
    window2.title('Coffee machine')

    lbl1= tk.Label(window2, text = 'Your chosen drink is: CAPPUCCINO')
    lbl1.configure(font=("Bernard MT", 13, 'bold'))
    lbl1.place(x = 950, y = 50)

    cost = tk.Label(window2, text = 'Cost: 1,00 credit')
    cost.place(x = 950, y = 70)
    
    clear_btn = tk.Button(window2, text='GO BACK', bg="red", fg='white', command=window2.destroy)
    clear_btn.place(x = 950, y = 500)

def play():
    window = tk.Tk()
    window.geometry('1920x1080')
    window.title('Coffee machine')

    image1 = Image.open("lavazza_transp.png")
    img = ImageTk.PhotoImage(image1)

    lbl1_img = tk.Label(image=img)
    lbl1_img.place(x= 100, y= 370)
    lbl1 = tk.Label(window, text='Choose a coffee!')
    lbl1.configure(font=("Bernard MT", 30, 'bold'))
    lbl1.place(x = 250, y = 30)
    
    coffee1_btn = tk.Button(window, text='Latte', bg="#604CDE", fg='white', command=latte)
    coffee1_btn.place(x = 220, y = 150)
    coffee1_btn.config(height = 5, width = 15)

    coffee2_btn = tk.Button(window, text='Espresso', bg="#604CDE", fg='white', command=espresso)
    coffee2_btn.place(x = 470, y = 150)
    coffee2_btn.config(height = 5, width = 15)

    coffee3_btn = tk.Button(window, text='Mochaccino', bg="#604CDE", fg='white', command=mochaccino)
    coffee3_btn.place(x = 220, y = 270)
    coffee3_btn.config(height = 5, width = 15)

    coffee4_btn = tk.Button(window, text='Cappuccino', bg="#604CDE", fg='white', command=cappuccino)
    coffee4_btn.place(x =470, y = 270)
    coffee4_btn.config(height = 5, width = 15)

    window.mainloop()

play()