from asyncore import compact_traceback
from calendar import c
from re import X
import tkinter as tk
from tkinter import ttk
from tkinter import *
from tkinter.font import BOLD
from tkinter.ttk import Progressbar
from turtle import back
from xml.dom.pulldom import END_DOCUMENT
from PIL import ImageTk, Image
import time


window = tk.Tk()
window.geometry('1920x1080')
window.title('Coffee machine')


image1 = Image.open("lavazza_transp.png")
img = ImageTk.PhotoImage(image1)

lbl1_img = tk.Label(image=img)
lbl1_img.place(x= 360, y= 370)

# image2 = Image.open("background_img.jpg")
# image2 = image2.resize((450,280), Image.ANTIALIAS)
# img2 = ImageTk.PhotoImage(image2)

#lbl2_img = tk.Label(image=img2)
#lbl2_img.place(x= 870, y= 148)


def latte():
    window2 = tk.Tk()
    window2.geometry('1080x720')
    window2.title('Purchase')

    # photo1 = Image.open("latte.png")
    # pht = ImageTk.PhotoImage(photo1)

    # img1 = tk.Label(window2, image = pht)
    # img1.place(x=300, y=300, height=4, width=3)

    def step():
        for x in range(5):
            lbl.config(text=progress['value'] + 20)
            progress['value'] += 20
            window.update_idletasks()
            time.sleep(1)
        if progress['value'] == 100:
            done = tk.Label(window2, text='Your coffee is ready!')
            done.configure(font=("Bernard MT", 15, 'italic'))
            done.place(x=445, y=400)

    def zahar():
        zahar1['value'] += 20
        lbl2.config(text=zahar1['value'])

    def stop():
        zahar1.stop()
        lbl2.destroy()

    lbl1= tk.Label(window2, text = 'Your chosen drink is: LATTE')
    lbl1.configure(font=("Bernard MT", 18, 'bold'))
    lbl1.place(x=400, y = 50)

    coffee_sort = tk.Label(window2, text = 'Choose type:')
    coffee_sort.configure(font=("Bernard MT", 10, 'bold'))
    coffee_sort.place(x=505, y=150)

    weak = tk.Button(window2, text='Weak', bg="#604CDE", fg='white',
height = 3, width = 12, command=step)
    weak.place(x=400, y=200)

    strong = tk.Button(window2, text='Strong', bg="#604CDE",
fg='white', height = 3, width = 12, command=step)
    strong.place(x=590, y=200)

    zaharplus = tk.Button(window2, text='Add sugar', bg="#604CDE",
fg='white', height = 2, width = 10, command=zahar)
    zaharplus.place(x=800, y=100)

    zaharbez = tk.Button(window2, text='Without sugar', bg="#604CDE",
fg='white', height = 2, width = 10, command=stop)
    zaharbez.place(x=900, y=100)

    quit_btn = tk.Button(window2, text='Go back', bg="red",
fg='white', command=window2.destroy)
    quit_btn.place(x = 950, y = 600)

    progress = ttk.Progressbar(window2, orient=HORIZONTAL, length=300,
mode='determinate')
    progress.pack(pady=20)
    progress.place(x=393, y=300)

    zahar1 = ttk.Progressbar(window2, orient=HORIZONTAL, length=180,
mode='determinate')
    zahar1.pack(pady=20)
    zahar1.place(x=800, y=150)

    lbl = tk.Label(window2, text="")
    lbl.pack(pady=20)
    lbl.place(x=530, y = 250)

    lbl2 = tk.Label(window2, text="")
    lbl2.pack(pady=20)
    lbl2.place(x=875, y = 220)



def espresso():
    window2 = tk.Tk()
    window2.geometry('1080x720')
    window2.title('Purchase')

    def step():
        for x in range(5):
            lbl.config(text=progress['value'] + 20)
            progress['value'] += 20
            window.update_idletasks()
            time.sleep(1)
        if progress['value'] == 100:
            done = tk.Label(window2, text='Your coffee is ready!')
            done.configure(font=("Bernard MT", 15, 'italic'))
            done.place(x=445, y=400)

    def zahar():
        zahar1['value'] += 20
        lbl2.config(text=zahar1['value'])

    def stop():
        zahar1.stop()
        lbl2.destroy()

    lbl1= tk.Label(window2, text = 'Your chosen drink is: ESPRESSO')
    lbl1.configure(font=("Bernard MT", 18, 'bold'))
    lbl1.place(x=400, y = 50)

    coffee_sort = tk.Label(window2, text = 'Choose type:')
    coffee_sort.configure(font=("Bernard MT", 10, 'bold'))
    coffee_sort.place(x=505, y=150)

    weak = tk.Button(window2, text='Weak', bg="#604CDE", fg='white',
height = 3, width = 12, command=step)
    weak.place(x=400, y=200)

    strong = tk.Button(window2, text='Strong', bg="#604CDE",
fg='white', height = 3, width = 12, command=step)
    strong.place(x=590, y=200)

    zaharplus = tk.Button(window2, text='Add sugar', bg="#604CDE",
fg='white', height = 2, width = 10, command=zahar)
    zaharplus.place(x=800, y=100)

    zaharbez = tk.Button(window2, text='Without sugar', bg="#604CDE",
fg='white', height = 2, width = 10, command=stop)
    zaharbez.place(x=900, y=100)

    quit_btn = tk.Button(window2, text='Go back', bg="red",
fg='white', command=window2.destroy)
    quit_btn.place(x = 950, y = 600)

    progress = ttk.Progressbar(window2, orient=HORIZONTAL, length=300,
mode='determinate')
    progress.pack(pady=20)
    progress.place(x=393, y=300)

    zahar1 = ttk.Progressbar(window2, orient=HORIZONTAL, length=180,
mode='determinate')
    zahar1.pack(pady=20)
    zahar1.place(x=800, y=150)

    lbl = tk.Label(window2, text="")
    lbl.pack(pady=20)
    lbl.place(x=530, y = 250)

    lbl2 = tk.Label(window2, text="")
    lbl2.pack(pady=20)
    lbl2.place(x=875, y = 220)


def mochaccino():
    window2 = tk.Tk()
    window2.geometry('1080x720')
    window2.title('Purchase')

    def step():
        for x in range(5):
            lbl.config(text=progress['value'] + 20)
            progress['value'] += 20
            window.update_idletasks()
            time.sleep(1)
        if progress['value'] == 100:
            done = tk.Label(window2, text='Your coffee is ready!')
            done.configure(font=("Bernard MT", 15, 'italic'))
            done.place(x=445, y=400)

    def zahar():
        zahar1['value'] += 20
        lbl2.config(text=zahar1['value'])

    def stop():
        zahar1.stop()
        lbl2.destroy()

    lbl1= tk.Label(window2, text = 'Your chosen drink is: MOCHACCINO')
    lbl1.configure(font=("Bernard MT", 18, 'bold'))
    lbl1.place(x=400, y = 50)

    coffee_sort = tk.Label(window2, text = 'Choose type:')
    coffee_sort.configure(font=("Bernard MT", 10, 'bold'))
    coffee_sort.place(x=505, y=150)

    weak = tk.Button(window2, text='Weak', bg="#604CDE", fg='white',
height = 3, width = 12, command=step)
    weak.place(x=400, y=200)

    strong = tk.Button(window2, text='Strong', bg="#604CDE",
fg='white', height = 3, width = 12, command=step)
    strong.place(x=590, y=200)

    zaharplus = tk.Button(window2, text='Add sugar', bg="#604CDE",
fg='white', height = 2, width = 10, command=zahar)
    zaharplus.place(x=800, y=100)

    zaharbez = tk.Button(window2, text='Without sugar', bg="#604CDE",
fg='white', height = 2, width = 10, command=stop)
    zaharbez.place(x=900, y=100)

    quit_btn = tk.Button(window2, text='Go back', bg="red",
fg='white', command=window2.destroy)
    quit_btn.place(x = 950, y = 600)

    progress = ttk.Progressbar(window2, orient=HORIZONTAL, length=300,
mode='determinate')
    progress.pack(pady=20)
    progress.place(x=393, y=300)

    zahar1 = ttk.Progressbar(window2, orient=HORIZONTAL, length=180,
mode='determinate')
    zahar1.pack(pady=20)
    zahar1.place(x=800, y=150)

    lbl = tk.Label(window2, text="")
    lbl.pack(pady=20)
    lbl.place(x=530, y = 250)

    lbl2 = tk.Label(window2, text="")
    lbl2.pack(pady=20)
    lbl2.place(x=875, y = 220)

def cappuccino():
    window2 = tk.Tk()
    window2.geometry('1080x720')
    window2.title('Purchase')

    def step():
        for x in range(5):
            lbl.config(text=progress['value'] + 20)
            progress['value'] += 20
            window.update_idletasks()
            time.sleep(1)
        if progress['value'] == 100:
            done = tk.Label(window2, text='Your coffee is ready!')
            done.configure(font=("Bernard MT", 15, 'italic'))
            done.place(x=445, y=400)

    def zahar():
        zahar1['value'] += 20
        lbl2.config(text=zahar1['value'])

    def stop():
        zahar1.stop()
        lbl2.destroy()

    lbl1= tk.Label(window2, text = 'Your chosen drink is: CAPPUCCINO')
    lbl1.configure(font=("Bernard MT", 18, 'bold'))
    lbl1.place(x=400, y = 50)

    coffee_sort = tk.Label(window2, text = 'Choose type:')
    coffee_sort.configure(font=("Bernard MT", 10, 'bold'))
    coffee_sort.place(x=505, y=150)

    weak = tk.Button(window2, text='Weak', bg="#604CDE", fg='white',
height = 3, width = 12, command=step)
    weak.place(x=400, y=200)

    strong = tk.Button(window2, text='Strong', bg="#604CDE",
fg='white', height = 3, width = 12, command=step)
    strong.place(x=590, y=200)

    zaharplus = tk.Button(window2, text='Add sugar', bg="#604CDE",
fg='white', height = 2, width = 10, command=zahar)
    zaharplus.place(x=800, y=100)

    zaharbez = tk.Button(window2, text='Without sugar', bg="#604CDE",
fg='white', height = 2, width = 10, command=stop)
    zaharbez.place(x=900, y=100)

    quit_btn = tk.Button(window2, text='Go back', bg="red",
fg='white', command=window2.destroy)
    quit_btn.place(x = 950, y = 600)

    progress = ttk.Progressbar(window2, orient=HORIZONTAL, length=300,
mode='determinate')
    progress.pack(pady=20)
    progress.place(x=393, y=300)

    zahar1 = ttk.Progressbar(window2, orient=HORIZONTAL, length=180,
mode='determinate')
    zahar1.pack(pady=20)
    zahar1.place(x=800, y=150)

    lbl = tk.Label(window2, text="")
    lbl.pack(pady=20)
    lbl.place(x=530, y = 250)

    lbl2 = tk.Label(window2, text="")
    lbl2.pack(pady=20)
    lbl2.place(x=875, y = 220)


lbl1 = tk.Label(window, text='Choose a coffee!')
lbl1.configure(font=("Bernard MT", 30, 'bold'))
lbl1.place(x = 510, y = 30)

coffee1_btn = tk.Button(window, text='Latte', bg="#604CDE",
fg='white', command=latte)
coffee1_btn.place(x = 480, y = 150)
coffee1_btn.config(height = 5, width = 15)

coffee2_btn = tk.Button(window, text='Espresso', bg="#604CDE",
fg='white', command=espresso)
coffee2_btn.place(x = 750, y = 150)
coffee2_btn.config(height = 5, width = 15)

coffee3_btn = tk.Button(window, text='Mochaccino', bg="#604CDE",
fg='white', command=mochaccino)
coffee3_btn.place(x = 480, y = 270)
coffee3_btn.config(height = 5, width = 15)

coffee4_btn = tk.Button(window, text='Cappuccino', bg="#604CDE",
fg='white', command=cappuccino)
coffee4_btn.place(x = 750, y = 270)
coffee4_btn.config(height = 5, width = 15)

tel = tk.Label(window, text = 'Email adress in case of damage:lavazza_coffee@gmail.com')
tel.configure(font=("Bernard MT", 10, 'bold'))
tel.place(x = 880, y = 660)

quit = tk.Button(window, text = 'Quit', command=window.quit)
quit.place(x=1200, y = 600)

window.mainloop()